# Clothier Android App

This revision restructures the existing WebView-based Clothier app around the approved clothing-shop workflow and frosted-glass visual direction.

## UI and navigation

- Frosted/translucent glass cards, floating navigation and rounded controls.
- Light/dark appearance follows the Android system theme.
- Status-bar, display-cutout and bottom gesture/navigation insets are passed into the WebView so content and the floating navigation stay clear of system UI.
- The main bottom navigation is **Home / Search / Products / Account**.
- Add Stock is a dedicated full-screen workflow; the bottom navigation is hidden while entering a product so it cannot overlap the form.
- Android back navigation follows the actual page history: Product -> Style -> Sub-category -> Main category -> Home, one step at a time.
- Selecting a root bottom-navigation tab replaces the current root route instead of leaving unwanted category history behind it.

## Catalog workflow

- Home shows Top Wear and Bottom Wear.
- Opening a main department shows sub-categories such as Shirts, T-Shirts, Jeans, etc.
- Sub-category cards provide **Open** and, in Admin Mode, **Delete**.
- Opening a sub-category shows **Add Category** at the top and its child style/categories below.
- Opening a child category shows its products.
- Admin **Add Stock** is available from Home and Products only while Admin Mode is enabled.

## Product availability

Clothier does **not** track quantities.

Removed:
- Available Stock / stock counts
- Low Stock system and alerts
- Stock History
- Quantity fields

Each product has only an **In Stock / Out of Stock** status. Admin can switch the status and can delete a product.

## Product details

Product details support the approved functional ideas:
- Large product photo
- Category / sub-category / style hierarchy
- Price
- Description
- Available colors
- Available sizes with customer selection
- In Stock / Out of Stock status
- Show Customer view
- Admin Edit, status toggle and Delete Product actions

## Photos, OCR and QR/barcode scanning

- Product photos use the Android native chooser with Camera or Gallery.
- Product-photo text extraction is connected to ML Kit text recognition.
- Search includes a QR/barcode scan action. It can take a photo with the camera or choose an image from the gallery, then uses ML Kit barcode scanning and places the decoded value into product search.

## Shop setup and account

First launch asks for shop details including shop name, owner, phone, address, UPI ID, optional UPI QR photo and store note.

The shop name appears in the top-left after setup. Account includes the Admin Mode switch, system-theme information, shop details and the Google/cloud-sync entry point.

Live Google sign-in and cross-device cloud synchronization still require the app owner's Firebase Authentication/Firestore project configuration. No fake credentials are included.

## Build

Open the project in Android Studio or use the included GitHub Actions workflow and allow Gradle to resolve AndroidX and ML Kit dependencies. The project targets Android API 35 and uses Kotlin/JVM 17.
