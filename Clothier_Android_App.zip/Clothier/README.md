# Clothier

Clothier is a reusable clothing-retail catalog Android app built from the Clothier HTML catalog and packaged in a lightweight Android shell.

## Features included

- Universal **Clothier** branding; no personal/family shop name.
- Top Wear: **Shirts, T-Shirts, Jackets & Coats**.
- Bottom Wear: **Pants, Jeans, Trousers, Baggy, Bootcut, Joggers**.
- Shirt organization with **Half Sleeve Shirts** and **Full Sleeve / Long Sleeve Shirts**, plus Checked, Printed, Party Wear, Plain/Solid, Designer, Stone Work and Brushed Cotton styles.
- Top sizes: **S, M, L, XL, XXL, 3XL, 4XL**.
- Bottom sizes: **28, 30, 32, 34, 36, 38, 40, 42, 44**.
- Size selection changes automatically according to Top Wear or Bottom Wear.
- **+ Add Category** at department/category/style levels.
- Custom categories persist with LocalStorage.
- **Admin Mode** with **+ Add Stock**.
- Stock fields: item name, ₹ price, department, sub-category, style, fabric/material, fit, colors, sizes, photo URL and sample-photo button.
- Responsive phone/tablet catalog layout.
- Search, size filter and fit filter.
- UPI QR/payment section for Google Pay, PhonePe, Paytm and other UPI apps.
- Cash/Card counter payment section.
- Offline-first LocalStorage inventory, category and store settings.
- **Clothier launcher icon** using the supplied 512×512 and 192×192 logo images.

## GitHub setup

1. Create a new GitHub repository named `Clothier`.
2. Description:
   `Clothier – A professional offline-ready clothing catalog and retail inventory management app.`
3. Upload the contents of this project so `app/`, `build.gradle.kts`, `settings.gradle.kts` and `.github/` are at the repository root.
4. Commit the files.
5. Open **Actions**.
6. Choose **Build Clothier APK**.
7. Click **Run workflow** → select `main` → **Run workflow**.
8. Wait for all steps to finish with green checks.
9. Open the completed workflow run and download the **Clothier-APK** artifact.
10. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Local web catalog

The original HTML catalog is packaged inside `app/src/main/assets/index.html` together with the supplied logo assets.

## Notes

The APK is a debug build for testing and personal use. Product images entered as external URLs require internet access; the catalog itself and its LocalStorage data are designed to work offline.
