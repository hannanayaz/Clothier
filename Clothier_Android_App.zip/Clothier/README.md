# Clothier

Professional clothing catalog and retail inventory Android app.

## Included
- Top Wear and Bottom Wear catalog
- Requested garment/style categories
- Dynamic sizes: S–4XL for tops and 28–44 for bottoms
- Add Category and Admin Mode
- Add Stock with price, fabric, fit, colors, sizes and image
- UPI QR, cash and card payment section
- Offline/localStorage data
- Responsive phone/tablet UI
- Universal Clothier branding and launcher icons
- Shop-name setting
- Continue with Google UI prepared for Firebase-based cloud sync

## Google Sync note
The button is included, but live Google sign-in and cross-device sync require a Firebase Authentication + Firestore project belonging to the app owner. No credentials are hard-coded into this reusable ZIP.

## GitHub build
The included workflow uses GitHub Actions and installs Gradle directly, so a Gradle wrapper is not required in the uploaded ZIP.
