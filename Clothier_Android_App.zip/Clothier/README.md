# Clothier Android App

This version keeps the existing WebView-based Clothier UI and applies the requested fixes without redesigning unrelated screens.

## Updated in this build

- Admin **Add Stock** is shown on the Home screen only, above Departments, while Admin Mode is active.
- Removed the old **Add/Manage** action from Top Wear department cards. They now show **Open** and **Delete** only.
- When an admin opens a sub-category such as **Shirts**, **Add Category** appears at the top and creates a child style/category there.
- Product photos use the Android native photo chooser, which offers **Camera** and **Gallery**.
- Product photo OCR is connected to Android ML Kit text recognition.
- Shop setup collects shop name, owner, phone, address, UPI ID, QR and store note.
- Shop name is clickable in the top-left and opens Shop & Account, including the Google sync entry point.
- UPI QR setup/settings can take or choose a QR photo from Camera/Gallery and preview it.
- Android status-bar, notch/display-cutout and bottom gesture/navigation safe areas are handled with window insets.
- Launcher icon uses an Android adaptive-icon foreground/background and a clean transparent logo mark.

## Google account/cloud sync

The UI and Android entry point are prepared for Firebase Authentication/Firestore, but live Google sign-in and cross-device cloud synchronization require the app owner's Firebase project configuration. No fake credentials are included.

## Build

Open the project in Android Studio and allow Gradle to resolve the AndroidX and ML Kit dependencies. The project targets Android API 35 and uses Kotlin/JVM 17.
