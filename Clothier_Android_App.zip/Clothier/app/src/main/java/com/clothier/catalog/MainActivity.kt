package com.clothier.catalog

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Window
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.Base64

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingCameraAfterPermission = false
    private var cameraOutputUri: Uri? = null
    private val fileChooserRequest = 4101
    private val cameraPermissionRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        applySafeAreaHandling()

        webView = WebView(this)
        setContentView(webView)
        webView.setBackgroundColor(0xFF0B0D10.toInt())
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                filePath: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePath
                showPhotoSourceChooser()
                return true
            }
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }
        webView.addJavascriptInterface(NativeBridge(), "NativeBridge")
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun showPhotoSourceChooser() {
        AlertDialog.Builder(this)
            .setTitle("Choose Photo")
            .setItems(arrayOf("Take Photo with Camera", "Choose from Gallery")) { _, which ->
                if (which == 0) launchCamera() else launchGallery()
            }
            .setOnCancelListener { cancelFileChooser() }
            .show()
    }

    private fun launchGallery() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
            }
            startActivityForResult(intent, fileChooserRequest)
        } catch (_: Exception) {
            cancelFileChooser()
            Toast.makeText(this, "Gallery could not be opened.", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchCamera() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingCameraAfterPermission = true
            requestPermissions(arrayOf(Manifest.permission.CAMERA), cameraPermissionRequest)
            return
        }

        try {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            val cameraApps = packageManager.queryIntentActivities(cameraIntent, PackageManager.MATCH_DEFAULT_ONLY)
            if (cameraApps.isEmpty()) {
                cancelFileChooser()
                Toast.makeText(this, "No camera app is available on this device.", Toast.LENGTH_LONG).show()
                return
            }

            val imageFile = File.createTempFile("clothier_camera_", ".jpg", File(cacheDir, "images").also { it.mkdirs() })
            cameraOutputUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", imageFile)
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri)
            cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            for (info in cameraApps) {
                grantUriPermission(info.activityInfo.packageName, cameraOutputUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivityForResult(Intent.createChooser(cameraIntent, "Take photo with camera"), fileChooserRequest)
        } catch (_: Exception) {
            cameraOutputUri = null
            cancelFileChooser()
            Toast.makeText(this, "Camera could not be opened.", Toast.LENGTH_LONG).show()
        }
    }

    private fun cancelFileChooser() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        cameraOutputUri = null
        pendingCameraAfterPermission = false
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != cameraPermissionRequest) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            pendingCameraAfterPermission = false
            launchCamera()
        } else {
            pendingCameraAfterPermission = false
            cancelFileChooser()
            Toast.makeText(this, "Camera permission is required to take a photo.", Toast.LENGTH_LONG).show()
        }
    }

    private fun applySafeAreaHandling() {
        window.statusBarColor = 0xFF0B0D10.toInt()
        window.navigationBarColor = 0xFF0B0D10.toInt()
        WindowCompat.setDecorFitsSystemWindows(window, true)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != fileChooserRequest) return
        val callback = filePathCallback ?: return
        val result: Array<Uri> = if (resultCode == RESULT_OK) {
            when {
                cameraOutputUri != null -> arrayOf(cameraOutputUri!!)
                data?.data != null -> arrayOf(data.data!!)
                else -> emptyArray()
            }
        } else emptyArray()

        callback.onReceiveValue(result)
        filePathCallback = null
        cameraOutputUri = null
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun recognizeImageText(dataUrl: String) {
            try {
                val encoded = dataUrl.substringAfter(',', dataUrl)
                val bytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Base64.getDecoder().decode(encoded)
                } else {
                    android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                }
                val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw IllegalArgumentException("Could not decode image")
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { result ->
                        val escaped = org.json.JSONObject.quote(result.text ?: "")
                        webView.post { webView.evaluateJavascript("setNativeOcrText($escaped)", null) }
                        recognizer.close()
                    }
                    .addOnFailureListener { error ->
                        recognizer.close()
                        runOnUiThread {
                            Toast.makeText(this@MainActivity, "Could not read text: ${error.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
                        }
                    }
            } catch (_: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Could not read the selected photo.", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun signInWithGoogle() {
            runOnUiThread {
                Toast.makeText(this@MainActivity, "Connect your Firebase project to enable Google sign-in.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onBackPressed() {
        webView.evaluateJavascript("window.handleNativeBack ? window.handleNativeBack() : false") { result ->
            if (result != "true") super.onBackPressed()
        }
    }

    override fun onDestroy() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        cameraOutputUri = null
        webView.removeJavascriptInterface("NativeBridge")
        webView.destroy()
        super.onDestroy()
    }
}
