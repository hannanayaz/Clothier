package com.clothier.catalog

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Window
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import java.io.File
import java.util.Base64

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingCameraAfterPermission = false
    private var pendingQrAfterPermission = false
    private var cameraOutputUri: Uri? = null
    private val fileChooserRequest = 4101
    private val cameraPermissionRequest = 4102
    private val qrChooserRequest = 4103
    private var qrCameraOutputUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        applySafeAreaHandling()

        webView = WebView(this)
        setContentView(webView)
        webView.setBackgroundColor(0x00000000)
        ViewCompat.setOnApplyWindowInsetsListener(webView) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val top = bars.top
            val bottom = bars.bottom
            webView.post {
                webView.evaluateJavascript(
                    "document.documentElement.style.setProperty('--android-top-inset','${top}px');" +
                    "document.documentElement.style.setProperty('--android-bottom-inset','${bottom}px');",
                    null
                )
            }
            insets
        }
        ViewCompat.requestApplyInsets(webView)
        applySystemBarAppearance()
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                filePath: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePath
                showPhotoSourceChooser()
                return true
            }
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadsImagesAutomatically = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
        }
        webView.addJavascriptInterface(NativeBridge(), "NativeBridge")
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun showPhotoSourceChooser() {
        AlertDialog.Builder(this)
            .setTitle("Choose Photo")
            .setItems(arrayOf("Take Photo with Camera", "Choose from Gallery")) { _, which ->
                if (which == 0) launchCamera() else launchGallery()
            }
            .setOnCancelListener { cancelFileChooser() }
            .show()
    }

    private fun launchGallery() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
            }
            startActivityForResult(intent, fileChooserRequest)
        } catch (_: Exception) {
            cancelFileChooser()
            Toast.makeText(this, "Gallery could not be opened.", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchCamera() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            pendingCameraAfterPermission = true
            requestPermissions(arrayOf(Manifest.permission.CAMERA), cameraPermissionRequest)
            return
        }

        try {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            if (cameraIntent.resolveActivity(packageManager) == null) {
                cancelFileChooser()
                Toast.makeText(this, "No camera app is available.", Toast.LENGTH_LONG).show()
                return
            }

            val imageFile = File.createTempFile("clothier_camera_", ".jpg", File(cacheDir, "images").also { it.mkdirs() })
            cameraOutputUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", imageFile)
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri)
            cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(cameraIntent, fileChooserRequest)
        } catch (_: Exception) {
            cameraOutputUri = null
            cancelFileChooser()
            Toast.makeText(this, "Camera could not be opened.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showQrSourceChooser() {
        AlertDialog.Builder(this)
            .setTitle("Scan QR / Barcode")
            .setItems(arrayOf("Take Photo with Camera", "Choose from Gallery")) { _, which ->
                if (which == 0) launchQrCamera() else launchQrGallery()
            }
            .setOnCancelListener { }
            .show()
    }

    private fun launchQrGallery() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(intent, qrChooserRequest)
        } catch (_: Exception) {
            Toast.makeText(this, "Gallery could not be opened.", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchQrCamera() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingQrAfterPermission = true
            requestPermissions(arrayOf(Manifest.permission.CAMERA), cameraPermissionRequest)
            return
        }
        try {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            if (cameraIntent.resolveActivity(packageManager) == null) {
                Toast.makeText(this, "No camera app is available.", Toast.LENGTH_LONG).show()
                return
            }
            val imageFile = File.createTempFile("clothier_qr_", ".jpg", File(cacheDir, "images").also { it.mkdirs() })
            qrCameraOutputUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", imageFile)
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, qrCameraOutputUri)
            cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(cameraIntent, qrChooserRequest)
        } catch (_: Exception) {
            qrCameraOutputUri = null
            Toast.makeText(this, "Camera could not be opened.", Toast.LENGTH_LONG).show()
        }
    }

    private fun scanQrUri(uri: Uri) {
        try {
            val image = InputImage.fromFilePath(this, uri)
            BarcodeScanning.getClient().process(image)
                .addOnSuccessListener { codes ->
                    val value = codes.firstOrNull()?.rawValue ?: ""
                    val escaped = org.json.JSONObject.quote(value)
                    webView.post { webView.evaluateJavascript("setNativeScanResult($escaped)", null) }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Could not scan that image.", Toast.LENGTH_LONG).show()
                }
        } catch (_: Exception) {
            Toast.makeText(this, "Could not read the selected image.", Toast.LENGTH_LONG).show()
        }
    }

    private fun cancelFileChooser() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        cameraOutputUri = null
        pendingCameraAfterPermission = false
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != cameraPermissionRequest) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (pendingQrAfterPermission) {
                pendingQrAfterPermission = false
                launchQrCamera()
            } else {
                pendingCameraAfterPermission = false
                launchCamera()
            }
        } else {
            val wasQr = pendingQrAfterPermission
            pendingQrAfterPermission = false
            pendingCameraAfterPermission = false
            if (!wasQr) cancelFileChooser()
            Toast.makeText(this, "Camera permission is required.", Toast.LENGTH_LONG).show()
        }
    }

    private fun applySafeAreaHandling() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
    }

    private fun applySystemBarAppearance() {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.isAppearanceLightStatusBars = !night
        controller.isAppearanceLightNavigationBars = !night
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applySystemBarAppearance()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == qrChooserRequest) {
            if (resultCode == RESULT_OK) {
                val uri = qrCameraOutputUri ?: data?.data
                if (uri != null) scanQrUri(uri) else Toast.makeText(this, "No image selected.", Toast.LENGTH_LONG).show()
            }
            qrCameraOutputUri = null
            return
        }
        if (requestCode != fileChooserRequest) return
        val callback = filePathCallback ?: return
        val result: Array<Uri> = if (resultCode == RESULT_OK) {
            when {
                cameraOutputUri != null -> arrayOf(cameraOutputUri!!)
                data?.data != null -> arrayOf(data.data!!)
                else -> emptyArray()
            }
        } else emptyArray()

        callback.onReceiveValue(result)
        filePathCallback = null
        cameraOutputUri = null
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun recognizeImageText(dataUrl: String) {
            try {
                val encoded = dataUrl.substringAfter(',', dataUrl)
                val bytes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    Base64.getDecoder().decode(encoded)
                } else {
                    android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)
                }
                val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    ?: throw IllegalArgumentException("Could not decode image")
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                recognizer.process(InputImage.fromBitmap(bitmap, 0))
                    .addOnSuccessListener { result ->
                        val escaped = org.json.JSONObject.quote(result.text ?: "")
                        webView.post { webView.evaluateJavascript("setNativeOcrText($escaped)", null) }
                        recognizer.close()
                    }
                    .addOnFailureListener { error ->
                        recognizer.close()
                        runOnUiThread {
                            Toast.makeText(this@MainActivity, "Could not read text: ${error.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
                        }
                    }
            } catch (_: Exception) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Could not read the selected photo.", Toast.LENGTH_LONG).show()
                }
            }
        }

        @JavascriptInterface
        fun scanQrFromImage() {
            runOnUiThread { showQrSourceChooser() }
        }

        @JavascriptInterface
        fun signInWithGoogle() {
            runOnUiThread {
                Toast.makeText(this@MainActivity, "Connect your Firebase project to enable Google sign-in.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onBackPressed() {
        webView.evaluateJavascript("window.handleNativeBack ? window.handleNativeBack() : false") { result ->
            if (result != "true") super.onBackPressed()
        }
    }

    override fun onDestroy() {
        filePathCallback?.onReceiveValue(null)
        filePathCallback = null
        cameraOutputUri = null
        qrCameraOutputUri = null
        pendingQrAfterPermission = false
        webView.removeJavascriptInterface("NativeBridge")
        webView.destroy()
        super.onDestroy()
    }
}
